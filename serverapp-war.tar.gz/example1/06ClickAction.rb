require "selenium-webdriver"


Selenium::WebDriver::Firefox.driver_path = "/home/tranvan/training/selenium/Driver/geckodriver"
driver = Selenium::WebDriver.for :firefox

begin
  # Navigate to URL
  driver.get "https://google.com"

	driver.find_element(name: "q").send_keys "webdriver"

  element = driver.find_element :class, "hOoLGe"

	driver.action.move_to(element).click.perform

  sleep(5)
ensure
  driver.quit
end
