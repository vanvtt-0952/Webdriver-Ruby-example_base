require "selenium-webdriver"

Selenium::WebDriver::Chrome.driver_path = "/home/tranvan/training/selenium/Driver/chromedriver"
driver = Selenium::WebDriver.for :chrome

begin
  driver.get "http://the-internet.herokuapp.com/dropdown"

  sleep 2
  dropdowns = driver.find_element id: "dropdown"
  options = dropdowns.find_elements tag_name: "option"
  options.each { |option| option.click if option.text == "Option 1" }

  selected_option = options.map { |option| puts option.text if option.selected? }
  sleep 1

ensure
  driver.quit
end
