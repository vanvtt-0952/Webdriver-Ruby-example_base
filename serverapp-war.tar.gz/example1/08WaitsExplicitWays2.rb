require "selenium-webdriver"

Selenium::WebDriver::Firefox.driver_path = "/home/tranvan/training/selenium/Driver/geckodriver"
driver = Selenium::WebDriver.for :firefox


begin
  driver.get "file:///home/tranvan/training/selenium/ruby/workspace/example1/WaitExample.html"
  wait = Selenium::WebDriver::Wait.new timeout: 10
  txtP = wait.until{driver.find_element(:css, "p")}

  puts "result: " << txtP.text
ensure
  driver.quit
end
