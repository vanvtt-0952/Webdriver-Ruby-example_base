import org.mortbay.jetty.Connector;
import org.mortbay.jetty.Server;
import org.mortbay.jetty.nio.SelectChannelConnector;
import org.mortbay.jetty.security.SslSocketConnector;
import org.mortbay.jetty.webapp.WebAppContext;

import javax.servlet.Servlet;
import java.io.File;

import org.openqa.selenium.remote.server.DriverServlet;

public class AppServer {
	private Server server = new Server();

	public AppServer() throws Exception {
		WebAppContext context = new WebAppContext();
		context.setContextPath("/home/tranvan/training/selenium/ruby/workspace/example1/config-server");
		context.setWar(new File("."));
		server.addHandler(context);

		context.addServlet(DriverServlet.class, "/wd/*");

		SelectChannelConnector connector = new SelectChannelConnector();
		connector.setPort(3001);
		server.addConnector(connector);

		server.start();
	}
}
