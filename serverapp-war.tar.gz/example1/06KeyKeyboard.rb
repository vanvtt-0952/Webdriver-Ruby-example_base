require "selenium-webdriver"


Selenium::WebDriver::Firefox.driver_path = "/home/tranvan/training/selenium/Driver/geckodriver"
driver = Selenium::WebDriver.for :firefox

begin
  # Navigate to URL
  driver.get "https://google.com"

  search = driver.find_element(name: "q")

	driver.action.send_keys(search, "webdriver").perform

  driver.action.send_keys(:tab).perform
  sleep(5)
ensure
  driver.quit
end
