require "selenium-webdriver"


Selenium::WebDriver::Chrome.driver_path = "/home/tranvan/training/selenium/Driver/chromedriver"
driver = Selenium::WebDriver.for :chrome

begin
  driver.get "https://www.selenium.dev/documentation/en/webdriver/js_alerts_prompts_and_confirmations/"

  # Click the link to activate the alert
  driver.find_element(:link_text, "See an example alert").click

  # Store the alert reference in a variable
  alert = driver.switch_to.alert

  # Store the alert text in a variable
  alert_text = alert.text

  sleep(1)

  puts alert_text + "alert_text"

  # Press on OK button
  alert.accept

  sleep(1)

ensure
  driver.quit
end
