require "selenium-webdriver"


Selenium::WebDriver::Firefox.driver_path = "/home/tranvan/training/selenium/Driver/geckodriver"
driver = Selenium::WebDriver.for :firefox
begin
  # Navigate to URL
  driver.get "https://google.com"

  # Enter "webdriver" text and perform "ENTER" keyboard action
  driver.find_element(name: "q").send_keys "webdriver"
 driver.action.key_down(:control).send_keys("a").perform

  sleep(5)
ensure
  driver.quit
end

