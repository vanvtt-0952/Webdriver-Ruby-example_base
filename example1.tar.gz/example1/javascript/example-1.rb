require "selenium-webdriver"

Selenium::WebDriver::Firefox.driver_path = "/home/tranvan/training/selenium/Driver/geckodriver"
driver = Selenium::WebDriver.for :firefox

begin
  # Navigate to URL
  driver.get "https://www.google.com/"

  driver.execute_script("alert('Hi, ruby test')")
  sleep 1

ensure
  driver.quit
end
