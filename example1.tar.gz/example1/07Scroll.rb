require "selenium-webdriver"


Selenium::WebDriver::Chrome.driver_path = "/home/tranvan/training/selenium/Driver/chromedriver"
driver = Selenium::WebDriver.for :chrome

begin
  driver.get "https://www.selenium.dev/documentation/en/webdriver/web_element/"
  txt_link = driver.find_element xpath: "//*[@id='body-inner']/h5/a[1]"

  sleep(2)

  driver.action.move_to(txt_link)
  puts "text : " + txt_link.text

  sleep(1)

  driver.action.double_click(txt_link).perform

  sleep(1)

ensure
  driver.quit
end
