require "selenium-webdriver"


Selenium::WebDriver::Firefox.driver_path = "/home/tranvan/training/selenium/Driver/geckodriver"
driver = Selenium::WebDriver.for :firefox

begin
  # Navigate to URL
  driver.get "https://google.com"

  # Enter "webdriver" text and perform "ENTER" keyboard action
  txtSearch = driver.find_element(name: "q")

  # Enters text "qwerty" with keyDown SHIFT key and after keyUp SHIFT key (QWERTYqwerty)
  driver.action.key_down(:shift).send_keys(txtSearch, "selenium").key_up(:shift).send_keys("webdriver").perform

  sleep(5)
ensure
  driver.quit
end
